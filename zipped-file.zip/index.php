<?php

// Slience is Awesome!
