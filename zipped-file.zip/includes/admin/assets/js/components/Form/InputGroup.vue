<template>
    <div class="flex items-center w-full">
        <slot></slot>
    </div>
</template>
<script>
export default {
    name: 'InputGroup',
};
</script>