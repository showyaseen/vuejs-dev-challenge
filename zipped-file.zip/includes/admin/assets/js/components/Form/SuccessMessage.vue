<template>
    <div class="m-5 mx-5 p-5 bg-green-200 text-green-800 rounded-md block">
        <slot></slot>
    </div>
</template>
<script>
export default {
    name: 'SuccessMessage',
};
</script>