<template>
    <div class="flex h-10 items-center mb-2 w-full">
        <slot></slot>
    </div>
</template>
<script>
export default {
    name: 'InputList',
};
</script>