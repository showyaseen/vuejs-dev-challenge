<template>
    <h2 class="p-4 mb-4 border-transparent border-b border-b-gray-300 border-solid">
        <slot></slot>
    </h2>
</template>
<script>
export default {
    name: "SectionTitle"
};
</script>