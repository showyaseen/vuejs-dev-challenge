<template>
    <div class="mt-16 border-transparent border-t border-t-gray-300 border-solid">
        <slot></slot>
    </div>
</template>
<script>
export default {
    name: "FormFooter"
};
</script>