<template>
    <div class="p-0 max-w mt-6 bg-white shadow-md rounded-md">
        <slot></slot>
    </div>
</template>
<script>
export default {
    name: "ContentCard",
};
</script>